---
Title: My First Recipe
Category: Cookbook
Author: YourName
keywords: [CookBook, First]
table-use-row-colors: true
table-row-color: "D3D3D3"
toc: true
toc-title: Table of Content
toc-own-page: true
---

# Recipe: My First Recipe

## Goal

Tell a potential user about the things your plugin achieves

## Steps

1. Load the plugin.
2. Write a script to work with the plugin.
3. Run the script.

Example:

```csharp
var x = 10;
Dump(x);
```
